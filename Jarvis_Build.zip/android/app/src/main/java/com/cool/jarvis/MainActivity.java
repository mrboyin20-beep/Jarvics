package com.cool.jarvis;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
